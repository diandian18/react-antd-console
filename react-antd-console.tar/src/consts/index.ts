export const DEFAULT_TITLE = 'react-antd-console';
export const logo = '/images/logo.png';
export const tab_title = 'tab_title';
