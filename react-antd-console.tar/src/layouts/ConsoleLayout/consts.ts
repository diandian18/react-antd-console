export const ClassName__ConsoleLayout_RightSideMain = 'console-layout__right-side-main';
