export const MENU_ID = 'menu-id';
